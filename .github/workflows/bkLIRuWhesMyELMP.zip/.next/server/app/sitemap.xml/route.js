var R=require("../../chunks/[turbopack]_runtime.js")("server/app/sitemap.xml/route.js")
R.c("server/chunks/[root-of-the-server]__2dfe20a3._.js")
R.c("server/chunks/[root-of-the-server]__703022d1._.js")
R.m(29262)
R.m(8922)
module.exports=R.m(8922).exports
