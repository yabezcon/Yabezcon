var R=require("../../chunks/[turbopack]_runtime.js")("server/app/robots.txt/route.js")
R.c("server/chunks/[root-of-the-server]__449be6c9._.js")
R.c("server/chunks/[root-of-the-server]__703022d1._.js")
R.m(38285)
R.m(33102)
module.exports=R.m(33102).exports
