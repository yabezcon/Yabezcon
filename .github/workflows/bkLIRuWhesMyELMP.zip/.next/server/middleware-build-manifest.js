globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/97978097feebd34b.js",
      "static/chunks/turbopack-b96e5dac2d03e750.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/97978097feebd34b.js",
      "static/chunks/turbopack-22951118fab0db04.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/450acc479d793f2a.js",
    "static/chunks/47f477e3d2ef265b.js",
    "static/chunks/079d5ede7af38810.js",
    "static/chunks/8082ab48faca5ea1.js",
    "static/chunks/turbopack-48b36e5bc2400441.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];