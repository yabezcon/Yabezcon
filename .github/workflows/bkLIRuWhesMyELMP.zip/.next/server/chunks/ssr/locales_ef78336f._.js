module.exports=[22445,a=>{a.v(b=>Promise.all(["server/chunks/ssr/locales_am_json_5a6a2af3._.js"].map(b=>a.l(b))).then(()=>b(17387)))},82887,a=>{a.v(b=>Promise.all(["server/chunks/ssr/locales_en_json_6b79570a._.js"].map(b=>a.l(b))).then(()=>b(807)))}];

//# sourceMappingURL=locales_ef78336f._.js.map