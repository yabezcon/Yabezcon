__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/97978097feebd34b.js",
  "static/chunks/turbopack-b96e5dac2d03e750.js"
])
