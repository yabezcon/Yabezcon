__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/97978097feebd34b.js",
  "static/chunks/turbopack-22951118fab0db04.js"
])
