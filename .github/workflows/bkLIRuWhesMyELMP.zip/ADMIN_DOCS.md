# YABEZ Construction & Trading P.L.C. Website Administration Guide

This document provides a comprehensive guide for administering and maintaining the YABEZ Construction & Trading P.L.C. website. The website is built using Next.js, TailwindCSS, and features English and Amharic localization.

## 1. Project Structure

The project follows a standard Next.js application structure with additional directories for localization and data management.

```
yabez-construction/
├── app/
│   ├── [locale]/
│   │   ├── about/
│   │   │   └── page.tsx
│   │   ├── blog/
│   │   │   └── page.tsx
│   │   ├── boq/
│   │   │   └── page.tsx
│   │   ├── careers/
│   │   │   └── page.tsx
│   │   ├── contact/
│   │   │   └── page.tsx
│   │   ├── projects/
│   │   │   └── page.tsx
│   │   ├── services/
│   │   │   └── page.tsx
│   │   ├── profile/
│   │   │   └── page.tsx
│   │   └── layout.tsx
│   ├── api/
│   │   └── generate-profile-pdf/
│   │       └── route.ts
│   ├── globals.css
│   ├── layout.tsx
│   ├── robots.ts
│   └── sitemap.ts
├── components/
│   ├── Footer.tsx
│   ├── Header.tsx
│   ├── GoogleAnalytics.tsx
│   └── SEO.tsx
├── lib/
│   ├── data/
│   │   ├── blog.json
│   │   ├── careers.json
│   │   ├── projects.json
│   │   └── services.json
│   └── jsonld.ts
├── locales/
│   ├── am.json
│   └── en.json
├── i18n.ts
├── middleware.ts
├── next.config.ts
├── package.json
├── postcss.config.mjs
├── README.md
├── tailwind.config.ts
└── tsconfig.json
```

## 2. Content Management

Currently, the website uses local JSON files (`lib/data/`) for content. This setup is a placeholder for a full Headless CMS (like Strapi) integration.

### 2.1 Updating Content

To update content, modify the respective JSON files in `lib/data/`:

-   `blog.json`: For blog posts.
-   `careers.json`: For job openings.
-   `projects.json`: For project details.
-   `services.json`: For service descriptions.

Each entry in these JSON files supports both English (`en`) and Amharic (`am`) translations. Ensure both language fields are updated for full localization.

### 2.2 Future CMS Integration (Strapi)

The project is designed to easily integrate with a Headless CMS like Strapi. The current JSON structure mimics what would typically be retrieved from a CMS API. To integrate Strapi:

1.  **Set up Strapi**: Install and configure a Strapi instance (refer to Strapi documentation).
2.  **Create Content Types**: Define content types in Strapi that match the structure of `blog.json`, `careers.json`, `projects.json`, and `services.json`.
3.  **Populate Content**: Seed the Strapi CMS with your content.
4.  **Update API Calls**: Modify the Next.js application to fetch data from the Strapi API instead of local JSON files. This typically involves using `axios` or `fetch` in `getServerSideProps` or `getStaticProps` (or equivalent App Router data fetching methods).

## 3. Localization (i18n)

The website supports English (`en`) and Amharic (`am`) languages using `next-intl`.

### 3.1 Translation Files

Translation strings are located in `locales/en.json` and `locales/am.json`. To add or modify translations, edit these JSON files.

### 3.2 Language Switching

The language switcher in the header allows users to toggle between English and Amharic. The `middleware.ts` file handles routing based on the selected locale.

## 4. Styling and Theming

TailwindCSS is used for styling, providing a utility-first CSS framework.

### 4.1 Brand Colors

Brand colors are defined in `app/globals.css` and `tailwind.config.ts`:

-   **Primary Blue**: `#0B5DA7`
-   **Secondary Gray**: `#2F3A3F`
-   **White**: `#FFFFFF`

These colors are available as CSS variables and TailwindCSS classes.

### 4.2 Amharic Font Support

`Noto Sans Ethiopic` is imported in `app/globals.css` to ensure proper rendering of Amharic characters across the website.

## 5. Forms

The Contact page (`app/[locale]/contact/page.tsx`) includes a contact form and a quote request form. Currently, these forms are client-side only and simulate submission. For production, they need to be integrated with a backend service (e.g., an API endpoint, email service, or CRM).

## 6. SEO and Analytics

### 6.1 JSON-LD Structured Data

JSON-LD for `Organization` and `Project` is implemented via `lib/jsonld.ts` and injected into the `head` of the `app/[locale]/layout.tsx`. This helps search engines understand the content better.

### 6.2 Sitemap and Robots.txt

-   `sitemap.ts`: Generates a dynamic sitemap (`/sitemap.xml`) for search engine crawling.
-   `robots.ts`: Configures `robots.txt` to guide search engine bots.

### 6.3 Google Analytics

Google Analytics is integrated via the `GoogleAnalytics.tsx` component. Replace `G-XXXXXXXXXX` in `app/[locale]/layout.tsx` with your actual Google Analytics Measurement ID.

## 7. Company Profile PDF

The Company Profile page (`app/[locale]/profile/page.tsx`) includes a button to download a PDF version of the company profile. The PDF generation is handled by a placeholder API route (`app/api/generate-profile-pdf/route.ts`). In a production environment, this route would use a server-side PDF generation library (e.g., Puppeteer, jsPDF on Node.js) to create a dynamic and well-formatted PDF.

## 8. Deployment to Vercel

This Next.js application is optimized for deployment on Vercel.

1.  **Install Vercel CLI**: `npm install -g vercel`
2.  **Login**: `vercel login`
3.  **Deploy**: Navigate to the project root (`/home/ubuntu/yabez-construction`) and run `vercel`. Follow the prompts to link your project and deploy.

## 9. Performance and Accessibility

### 9.1 Lighthouse Optimization

The website is developed with performance in mind, aiming for high scores on Google Lighthouse. Key optimizations include:

-   **Image Optimization**: Next.js Image component (if used for actual images) and `image/avif`, `image/webp` formats configured in `next.config.ts`.
-   **Code Splitting**: Next.js automatically splits code for faster loading.
-   **CSS Optimization**: TailwindCSS purges unused CSS, and `optimizeCss` is enabled in `next.config.ts`.
-   **Static Generation**: Most pages are statically generated for fast delivery.

### 9.2 WCAG 2.1 AA Accessibility

The website adheres to WCAG 2.1 AA accessibility standards through:

-   **Semantic HTML**: Proper use of HTML elements for structure and meaning.
-   **Keyboard Navigation**: Ensuring all interactive elements are navigable via keyboard.
-   **Color Contrast**: Brand colors are chosen to meet contrast requirements.
-   **Localization**: Content is available in multiple languages.
-   **Font Support**: Noto Sans Ethiopic is used to ensure proper rendering of Amharic text.

## 10. Future Enhancements

-   **Full CMS Integration**: Replace the mock JSON data with a headless CMS like Strapi for more robust content management.
-   **Before/After Slider**: Implement a before/after image slider for project showcases.
-   **Advanced Forms**: Integrate with a backend service for contact and quote form submissions.
-   **Dynamic BOQ Downloads**: Implement a system to manage and serve BOQ documents dynamically.
-   **Image Gallery**: Implement a more robust image gallery with lazy loading and lightbox functionality.

This guide should provide the necessary information to manage and maintain the YABEZ Construction & Trading P.L.C. website. For any further assistance, please refer to the Next.js and TailwindCSS documentation.
